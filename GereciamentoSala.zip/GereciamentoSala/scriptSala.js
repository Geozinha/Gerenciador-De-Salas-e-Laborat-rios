class reservas{
    constructor(professor){
        
    }
}

const textarea = document.querySelector('textarea');
textarea.addEventListener('keyup', (e) =>{
    textarea.style.height= 'auto';
    let scHeight=e.target.scollHeight;
    textarea.style.height= `{scHeight}px`;
})