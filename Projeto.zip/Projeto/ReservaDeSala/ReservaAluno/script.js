// Função para adicionar uma nova sala à lista de opções no formulário de reserva e à lista de salas disponíveis
function adicionarSalaAoFormulario(sala) {
    const selectSala = document.getElementById('sala');
    const option = document.createElement('option');
    option.textContent = sala.nome;
    option.value = sala.id;
    selectSala.appendChild(option);

    const listaSalas = document.getElementById('lista-salas');
    const li = document.createElement('li');
    li.className = 'sala';
    li.innerHTML = `
        <span><strong>Nome:</strong> ${sala.nome}</span>
        <span><strong>Descrição:</strong> ${sala.descricao}</span>
        <span><strong>Quantidade de Alunos:</strong> ${sala.qtdAlunos}</span>
        <span><strong>Prédio:</strong> ${sala.predio}</span>
    `;
    listaSalas.appendChild(li);
}

// Função para adicionar uma reserva à lista de reservas feitas
function adicionarReserva(reserva) {
    const listaReservas = document.getElementById('lista-reservas');
    const li = document.createElement('li');
    li.className = 'reserva';
    li.innerHTML = `
        <span><strong>Sala:</strong> ${reserva.sala}</span>
        <span><strong>Data:</strong> ${reserva.data}</span>
        <span><strong>Horário:</strong> ${reserva.horaInicio} - ${reserva.horaFim}</span>
        <span><strong>Descrição:</strong> ${reserva.descricao}</span>
        <button class="btn-remover-reserva" data-reserva-id="${reserva.id}">Remover</button>
    `;
    listaReservas.appendChild(li);
    
    // Limpar formulário de reserva após adicionar a reserva
    document.getElementById('form-reserva-sala').reset();
}

// Simulação de um banco de dados de salas e reservas
let salas = [];
let reservas = [];

// Event listener para o formulário de reserva de sala
document.getElementById('form-reserva-sala').addEventListener('submit', function(event) {
    event.preventDefault();

    // Capturar os valores do formulário
    const salaId = document.getElementById('sala').value;
    const dataReserva = document.getElementById('data-reserva').value;
    const horaInicio = document.getElementById('hora-inicio').value;
    const horaFim = document.getElementById('hora-fim').value;
    const descricaoReserva = document.getElementById('descricao-reserva').value;

    // Encontrar o nome da sala com base no ID selecionado
    const salaSelecionada = salas.find(sala => sala.id == salaId);
    const nomeSala = salaSelecionada ? salaSelecionada.nome : 'Sala não encontrada';

    // Simular geração de ID único para a reserva (para simplificação do exemplo)
    const idReserva = reservas.length + 1;

    // Criar objeto reserva
    const reserva = {
        id: idReserva,
        sala: nomeSala,
        data: dataReserva,
        horaInicio: horaInicio,
        horaFim: horaFim,
        descricao: descricaoReserva
    };

    // Adicionar reserva ao array de reservas
    reservas.push(reserva);

    // Adicionar reserva à lista de reservas feitas
    adicionarReserva(reserva);
});

// Função para renderizar a lista de reservas
function renderReservas() {
    const listaReservas = document.getElementById('lista-reservas');
    listaReservas.innerHTML = '';
    reservas.forEach(reserva => {
        const li = document.createElement('li');
        li.className = 'reserva';
        li.innerHTML = `
            <span><strong>Sala:</strong> ${reserva.sala}</span>
            <span><strong>Data:</strong> ${reserva.data}</span>
            <span><strong>Horário:</strong> ${reserva.horaInicio} - ${reserva.horaFim}</span>
            <span><strong>Descrição:</strong> ${reserva.descricao}</span>
            <button class="btn-remover-reserva" data-reserva-id="${reserva.id}">Remover</button>
        `;
        listaReservas.appendChild(li);
    });
}

// Event listener para remover uma reserva (delegado para elementos dinâmicos)
document.getElementById('lista-reservas').addEventListener('click', function(event) {
    if (event.target.classList.contains('btn-remover-reserva')) {
        const reservaId = parseInt(event.target.dataset.reservaId);
        reservas = reservas.filter(reserva => reserva.id !== reservaId);
        renderReservas();
    }
});

// Simulação inicial de algumas salas disponíveis e uma reserva existente
document.addEventListener('DOMContentLoaded', function() {
    salas = [
        { id: 1, nome: 'Sala 101', descricao: 'Laboratório de Informática', qtdAlunos: 30, predio: '1' },
        { id: 2, nome: 'Sala 202', descricao: 'Sala de Aula Comum', qtdAlunos: 40, predio: '2' }
    ];
    salas.forEach(adicionarSalaAoFormulario);

    // Adicionar uma reserva já existente
    const reservaExistente = {
        id: 1,
        sala: 'Sala 101',
        data: '2024-06-15',
        horaInicio: '08:00',
        horaFim: '10:00',
        descricao: 'Aula de programação'
    };
    reservas.push(reservaExistente);
    adicionarReserva(reservaExistente);

    renderReservas();
});
