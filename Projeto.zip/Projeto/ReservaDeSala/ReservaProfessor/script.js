// Função para adicionar uma nova sala à lista de opções no formulário de reserva
function adicionarSalaAoFormulario(sala) {
    const selectSala = document.getElementById('sala');
    const option = document.createElement('option');
    option.textContent = sala.nome;
    option.value = sala.id;
    selectSala.appendChild(option);
}

// Função para adicionar uma reserva à lista de reservas feitas
function adicionarReserva(reserva) {
    const listaReservas = document.getElementById('lista-reservas');
    const li = document.createElement('li');
    li.className = 'reserva';
    li.innerHTML = `
        <span><strong>Sala:</strong> ${reserva.sala}</span>
        <span><strong>Data:</strong> ${reserva.data}</span>
        <span><strong>Horário:</strong> ${reserva.horaInicio} - ${reserva.horaFim}</span>
        <button class="btn-editar-reserva" data-reserva-id="${reserva.id}">Editar</button>
        <button class="btn-remover-reserva" data-reserva-id="${reserva.id}">Remover</button>
    `;
    listaReservas.appendChild(li);
    
    // Limpar formulário de reserva após adicionar a reserva
    document.getElementById('form-reserva-sala').reset();
}

// Simulação de um banco de dados de salas e reservas
let salas = [];
let reservas = [];
let editIndex = null;

// Event listener para o formulário de cadastro de sala
document.getElementById('form-cadastro-sala').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Capturar os valores do formulário
    const nomeSala = document.getElementById('nome-sala').value;
    const descricaoSala = document.getElementById('descricao-sala').value;
    const qtdAlunos = document.getElementById('qtd-alunos').value;
    const predio = document.getElementById('predio').value;

    // Simular geração de ID único para a sala (para simplificação do exemplo)
    const idSala = salas.length + 1;

    // Criar objeto sala
    const sala = {
        id: idSala,
        nome: nomeSala,
        descricao: descricaoSala,
        qtdAlunos: qtdAlunos,
        predio: predio
    };

    // Adicionar sala ao array de salas
    salas.push(sala);

    // Adicionar sala como opção no formulário de reserva
    adicionarSalaAoFormulario(sala);

    // Limpar formulário de cadastro de sala após adicionar
    this.reset();
});

// Event listener para o formulário de reserva de sala
document.getElementById('form-reserva-sala').addEventListener('submit', function(event) {
    event.preventDefault();

    // Capturar os valores do formulário
    const salaId = document.getElementById('sala').value;
    const dataReserva = document.getElementById('data-reserva').value;
    const horaInicio = document.getElementById('hora-inicio').value;
    const horaFim = document.getElementById('hora-fim').value;

    // Encontrar o nome da sala com base no ID selecionado
    const salaSelecionada = salas.find(sala => sala.id == salaId);
    const nomeSala = salaSelecionada ? salaSelecionada.nome : 'Sala não encontrada';

    // Criar objeto reserva
    const reserva = {
        id: editIndex !== null ? reservas[editIndex].id : reservas.length + 1,
        sala: nomeSala,
        data: dataReserva,
        horaInicio: horaInicio,
        horaFim: horaFim
    };

    if (editIndex !== null) {
        reservas[editIndex] = reserva;
        editIndex = null;
    } else {
        reservas.push(reserva);
    }

    // Adicionar reserva à lista de reservas feitas
    adicionarReserva(reserva);
    renderReservas();
});

// Função para renderizar a lista de reservas
function renderReservas() {
    const listaReservas = document.getElementById('lista-reservas');
    listaReservas.innerHTML = '';
    reservas.forEach(reserva => {
        const li = document.createElement('li');
        li.className = 'reserva';
        li.innerHTML = `
            <span><strong>Sala:</strong> ${reserva.sala}</span>
            <span><strong>Data:</strong> ${reserva.data}</span>
            <span><strong>Horário:</strong> ${reserva.horaInicio} - ${reserva.horaFim}</span>
            <button class="btn-editar-reserva" data-reserva-id="${reserva.id}">Editar</button>
            <button class="btn-remover-reserva" data-reserva-id="${reserva.id}">Remover</button>
        `;
        listaReservas.appendChild(li);
    });
}

// Event listener para remover e editar uma reserva (delegado para elementos dinâmicos)
document.getElementById('lista-reservas').addEventListener('click', function(event) {
    const reservaId = parseInt(event.target.dataset.reservaId);
    const reservaIndex = reservas.findIndex(reserva => reserva.id === reservaId);

    if (event.target.classList.contains('btn-remover-reserva')) {
        reservas.splice(reservaIndex, 1);
        renderReservas();
    } else if (event.target.classList.contains('btn-editar-reserva')) {
        const reserva = reservas[reservaIndex];
        
        document.getElementById('sala').value = salas.find(sala => sala.nome === reserva.sala).id;
        document.getElementById('data-reserva').value = reserva.data;
        document.getElementById('hora-inicio').value = reserva.horaInicio;
        document.getElementById('hora-fim').value = reserva.horaFim;

        editIndex = reservaIndex;
    }
});

// Renderiza as reservas ao carregar a página
document.addEventListener('DOMContentLoaded', renderReservas);
