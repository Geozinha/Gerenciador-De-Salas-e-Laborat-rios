const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');
const formAluno = document.querySelector('.forma-container.cadastrar > form');
const loginBotaoProf = document.getElementById('loginBotaoProf');
const loginBotaoAluno = document.getElementById('loginBotaoAluno');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});


loginBotaoProf.addEventListener('click', function(event) {
    event.preventDefault(); // Evita o envio do formulário padrão
    window.location.href = '../ReservaProfessor/index.html'; // Caminho para a nova página
});

loginBotaoAluno.addEventListener('click', function(event) {
    event.preventDefault(); // Evita o envio do formulário padrão
    window.location.href = '../ReservaAluno/index.html'; // Caminho para a nova página
});
